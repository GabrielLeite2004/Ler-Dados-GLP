#include <stdio.h>
#include <string.h>

#define MAX_LINHA 125

// Defina uma estrutura (struct) para armazenar os dados
struct Dados {
    char regiao_sigla[MAX_LINHA];
    char estado_sigla[MAX_LINHA];
    char municipio[MAX_LINHA];
    char revenda[MAX_LINHA];
    char cnpj_revenda[MAX_LINHA];
    char nome_rua[MAX_LINHA];
    char numero_rua[MAX_LINHA];
    char complemento[MAX_LINHA];
    char bairro[MAX_LINHA];
    char cep[MAX_LINHA];
    char produto[MAX_LINHA];
    char data_coleta[MAX_LINHA];
    char valor_venda[MAX_LINHA];
    char valor_compra[MAX_LINHA];
    char unidade_medida[MAX_LINHA];
    char bandeira[MAX_LINHA];
};

int main() {
    FILE *arquivo;
    struct Dados dados; // Crie uma variável do tipo struct Dados para armazenar os dados de cada linha

    // Abra o arquivo CSV para leitura
    arquivo = fopen("glp-2004-01.csv", "r");
    if (arquivo == NULL) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }

    // Leia e descarte o cabeçalho
    fscanf(
        arquivo,
        "%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^\n]\n",
        dados.regiao_sigla, dados.estado_sigla, dados.municipio, dados.revenda, dados.cnpj_revenda,
        dados.nome_rua, dados.numero_rua, dados.complemento, dados.bairro, dados.cep, dados.produto,
        dados.data_coleta, dados.valor_venda, dados.valor_compra, dados.unidade_medida, dados.bandeira);
  printf(">>Regiao - Sigla: %s\n", dados.regiao_sigla);
  printf("Estado - Sigla: %s\n", dados.estado_sigla);
  printf("Municipio: %s\n", dados.municipio);
  printf("Revenda: %s\n", dados.revenda);
  printf("CNPJ da Revenda: %s\n", dados.cnpj_revenda);
  printf("Nome da Rua: %s\n", dados.nome_rua);
  printf("Numero Rua: %s\n", dados.numero_rua);
  printf("Complemento: %s\n", dados.complemento);
  printf("Bairro: %s\n", dados.bairro);
  printf("Cep: %s\n", dados.cep);
  printf("Produto: %s\n", dados.produto);
  printf("Data da Coleta: %s\n", dados.data_coleta);
  printf("Valor de Venda: %s\n", dados.valor_venda);
  printf("Valor de Compra: %s\n", dados.valor_compra);
  printf("Unidade de Medida: %s\n", dados.unidade_medida);
  printf("Bandeira: %s\n\n", dados.bandeira);
  getchar();

    // Use fscanf para ler cada linha no formato desejado
    while (fscanf(
        arquivo,
      "%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^\n]\n",
        dados.regiao_sigla, dados.estado_sigla, dados.municipio, dados.revenda, dados.cnpj_revenda,
        dados.nome_rua, dados.numero_rua, dados.complemento, dados.bairro, dados.cep, dados.produto,
        dados.data_coleta, dados.valor_venda, dados.valor_compra, dados.unidade_medida, dados.bandeira) !=EOF) {
        // Imprima os dados lidos
        printf("Regiao - Sigla: %s\n", dados.regiao_sigla);
        printf("Estado - Sigla: %s\n", dados.estado_sigla);
        printf("Municipio: %s\n", dados.municipio);
        printf("Revenda: %s\n", dados.revenda);
        printf("CNPJ da Revenda: %s\n", dados.cnpj_revenda);
        printf("Nome da Rua: %s\n", dados.nome_rua);
        printf("Numero Rua: %s\n", dados.numero_rua);
        printf("Complemento: %s\n", dados.complemento);
        printf("Bairro: %s\n", dados.bairro);
        printf("Cep: %s\n", dados.cep);
        printf("Produto: %s\n", dados.produto);
        printf("Data da Coleta: %s\n", dados.data_coleta);
        printf("Valor de Venda: %s\n", dados.valor_venda);
        printf("Valor de Compra: %s\n", dados.valor_compra);
        printf("Unidade de Medida: %s\n", dados.unidade_medida);
        printf("Bandeira: %s\n\n", dados.bandeira);
        getchar();
    }    

    // Feche o arquivo
    fclose(arquivo);

    return 0;
}
